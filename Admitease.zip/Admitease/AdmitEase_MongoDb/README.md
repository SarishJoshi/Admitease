# AdmitEase
### this is a web platform where students can fill the admission form online and college can see their apllication on our portal
### we had use mongodb as an database and had use node.js for connectivity with mongodb and .ejs file
<!-- node index.js -->
<!-- http://localhost:3000/ -->